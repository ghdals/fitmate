import { useNavigate } from "react-router-dom"; // useNavigate 훅을 import
import { StepLayout } from "../components/step-layout";
import { Button } from "../components/button";
import { Field, Label } from "../components/fieldset";
import { Heading } from "../components/heading";

function Step2Page() {
  const navigate = useNavigate(); // navigate 훅 사용

  const handlePrev = () => {
    navigate("/step1"); // "이전" 버튼 클릭 시 Step1으로 이동
  };

  const handleNext = () => {
    navigate("/step3"); // "다음" 버튼 클릭 시 Step3으로 이동
  };

  return (
    <StepLayout>
      <form className="grid w-full grid-cols-1 gap-6">
        <Heading>레벨을 선택하세요</Heading>
        <Field>
          <Label>레벨</Label>
          <div className="flex space-x-4">
            <Button type="button" className="flex-1 bg-zinc-800 hover:bg-zinc-700">
              초급자
            </Button>
            <Button type="button" className="flex-1 bg-zinc-800 hover:bg-zinc-700">
              중급자
            </Button>
            <Button type="button" className="flex-1 bg-zinc-800 hover:bg-zinc-700">
              상급자
            </Button>
          </div>
        </Field>

        {/* 이전 버튼: Step1으로 이동 */}
        <div className="flex space-x-4">
          <Button 
            type="button" 
            className="flex-1 bg-zinc-800 hover:bg-zinc-700"
            onClick={handlePrev} // 이전 페이지로 이동
          >
            이전
          </Button>

          {/* 다음 버튼: Step3으로 이동 */}
          <Button 
            type="button"  // type="button"으로 설정하여 폼 제출을 방지
            className="flex-1 bg-zinc-800 hover:bg-zinc-700"
            onClick={handleNext} // Step3으로 이동
          >
            다음
          </Button>
        </div>
      </form>
    </StepLayout>
  );
}

export default Step2Page;
