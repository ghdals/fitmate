function DetailPage() {
    return <h1>Detail Page</h1>;
  }
  
  export default DetailPage;
  