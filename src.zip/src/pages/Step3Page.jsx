import { useNavigate } from "react-router-dom";
import { StepLayout } from "../components/step-layout";
import { Button } from "../components/button";
import { Field, Label } from "../components/fieldset";
import { Heading } from "../components/heading";

function Step3Page() {
  const navigate = useNavigate();

  const handlePrev = () => {
    navigate("/step2"); // "이전" 버튼 클릭 시 Step2로 이동
  };

  const handleNext = () => {
    navigate("/step4"); // "다음" 버튼 클릭 시 Step4로 이동
  };

  return (
    <StepLayout>
      <form className="grid w-full grid-cols-1 gap-6">
        <Heading>운동 목표를 선택하세요</Heading>
        <Field>
          <Label>목표</Label>
          <div className="flex space-x-4">
            <Button type="button" className="flex-1 bg-zinc-800 hover:bg-zinc-700">
              체중 감량
            </Button>
            <Button type="button" className="flex-1 bg-zinc-800 hover:bg-zinc-700">
              근육 증가
            </Button>
            <Button type="button" className="flex-1 bg-zinc-800 hover:bg-zinc-700">
              유지
            </Button>
          </div>
        </Field>

        <div className="flex space-x-4">
          <Button
            type="button"
            className="flex-1 bg-zinc-800 hover:bg-zinc-700"
            onClick={handlePrev} // Step2으로 이동
          >
            이전
          </Button>

          <Button
            type="button"
            className="flex-1 bg-zinc-800 hover:bg-zinc-700"
            onClick={handleNext} // Step4로 이동
          >
            다음
          </Button>
        </div>
      </form>
    </StepLayout>
  );
}

export default Step3Page;
